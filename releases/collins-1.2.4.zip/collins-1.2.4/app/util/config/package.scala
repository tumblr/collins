package util
package object config {
  type TypesafeConfiguration = com.typesafe.config.Config
  type PlayConfiguration = play.api.Configuration
}
