package util.security

case class FileUserLoaderException(msg: String) extends Exception(msg)
