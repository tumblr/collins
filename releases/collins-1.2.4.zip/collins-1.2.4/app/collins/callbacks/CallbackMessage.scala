package collins.callbacks

case class CallbackMessage(name: String, oldValue: AnyRef, newValue: AnyRef)
