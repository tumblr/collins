package collins.power
package management

import play.api.Plugin

trait PowerManagementPlugin extends Plugin with PowerManagement
