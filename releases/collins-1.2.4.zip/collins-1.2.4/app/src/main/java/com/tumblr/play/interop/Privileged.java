package com.tumblr.play.interop;

import java.util.Map;
import java.util.List;

public class Privileged {
  public Map<String, List<String>> users;
  public Map<String, List<String>> permissions;
}
