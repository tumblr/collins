package com.tumblr.play.interop;

import java.util.Map;

public class JProvisionerProfile implements java.io.Serializable {
    static final long serialVersionUID = -8425566388153807286L;
    public Map<String, JProfile> profiles;
}
