module CollinsNotify
  class CollinsNotifyException < StandardError; end
  class ConfigurationError < CollinsNotifyException; end
end
