$:.unshift File.join File.dirname(__FILE__)
require 'collins/util'
require 'collins/option'
require 'collins/simple_callback'
require 'collins/asset'
require 'collins/client'
require 'collins/errors'
