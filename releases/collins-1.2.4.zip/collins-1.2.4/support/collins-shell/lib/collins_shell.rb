$:.unshift File.join File.dirname(__FILE__)
require 'collins_shell/errors'
require 'pp'
